package id.hardianadi.movieandshowlist.viewmodel

import androidx.lifecycle.ViewModel
import id.hardianadi.movieandshowlist.util.DataDummy

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class ShowViewModel : ViewModel() {

    fun getShows() = DataDummy.generateDummyMovies().filter { it.type == 2 }
}