package id.hardianadi.movieandshowlist.model

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
data class Movie(
    val id: Int,
    val title: String,
    val poster: String,
    val synopsis: String,
    val yearRelease: Int,
    val director: String,
    val type: Int
) {
    var casts: List<Cast>? = null
}