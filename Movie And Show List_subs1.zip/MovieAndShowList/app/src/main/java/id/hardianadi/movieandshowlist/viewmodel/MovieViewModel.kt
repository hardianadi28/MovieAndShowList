package id.hardianadi.movieandshowlist.viewmodel

import androidx.lifecycle.ViewModel
import id.hardianadi.movieandshowlist.util.DataDummy

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class MovieViewModel : ViewModel() {
    fun getMovieList() = DataDummy.generateDummyMovies().filter { it.type == 1 }
}