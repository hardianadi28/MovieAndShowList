package id.hardianadi.movieandshowlist.model

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
data class Cast(
    val id: Int,
    val idMovie: Int,
    val idStar: Int,
    val role: String
) {
    var star: Star? = null

}