package id.hardianadi.movieandshowlist.util

import id.hardianadi.movieandshowlist.model.Cast
import id.hardianadi.movieandshowlist.model.Movie
import id.hardianadi.movieandshowlist.model.Star

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
object DataDummy {


    fun generateDummyMovies(): List<Movie> {
        val movies = ArrayList<Movie>()
        var id = 0

        movies.add(
            Movie(
                ++id,
                "The Dark Knight",
                "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_SY1000_CR0,0,675,1000_AL_.jpg",
                "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice",
                2008,
                "Christopher Nolan",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "Breaking Bad",
                "https://m.media-amazon.com/images/M/MV5BMjhiMzgxZTctNDc1Ni00OTIxLTlhMTYtZTA3ZWFkODRkNmE2XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SY1000_CR0,0,718,1000_AL_.jpg",
                "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.",
                2008,
                "Vince Gilligan",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Avengers: Endgame",
                "https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_SY1000_CR0,0,674,1000_AL_.jpg",
                "After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos' actions and restore balance to the universe.",
                2019,
                "Anthony Russo, Joe Russo",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "Joker",
                "https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SY1000_CR0,0,674,1000_AL_.jpg",
                "In Gotham City, mentally troubled comedian Arthur Fleck is disregarded and mistreated by society. He then embarks on a downward spiral of revolution and bloody crime. This path brings him face-to-face with his alter-ego: the Joker.",
                2019,
                "Todd Phillips",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "Interstellar",
                "https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SY1000_SX675_AL_.jpg",
                "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival",
                2014,
                "Christopher Nolan",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Umbrella Academy",
                "https://m.media-amazon.com/images/M/MV5BNzA5MjkwYzMtNGY2MS00YWRjLThkNTktOTNmMzdlZjE3Y2IxXkEyXkFqcGdeQXVyMjkwMzMxODg@._V1_SY1000_CR0,0,680,1000_AL_.jpg",
                "A family of former child heroes, now grown apart, must reunite to continue to protect the world.",
                2019,
                "Steve Blackman, Jeremy Slater",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Man of Steel",
                "https://m.media-amazon.com/images/M/MV5BMTk5ODk1NDkxMF5BMl5BanBnXkFtZTcwNTA5OTY0OQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "An alien child is evacuated from his dying world and sent to Earth to live among humans. His peace is threatened, when other survivors of his home planet invade Earth.",
                2013,
                "Zack Snyder",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Witcher",
                "https://m.media-amazon.com/images/M/MV5BOGE4MmVjMDgtMzIzYy00NjEwLWJlODMtMDI1MGY2ZDlhMzE2XkEyXkFqcGdeQXVyMzY0MTE3NzU@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.",
                2019,
                "Lauren Schmidt",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Boys",
                "https://m.media-amazon.com/images/M/MV5BNGEyOGJiNWEtMTgwMi00ODU4LTlkMjItZWI4NjFmMzgxZGY2XkEyXkFqcGdeQXVyNjcyNjcyMzQ@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "A group of vigilantes sets out to take down corrupt superheroes who abuse their superpowers.",
                2019,
                "Eric Kripke",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Game of Thrones",
                "https://m.media-amazon.com/images/M/MV5BYTRiNDQwYzAtMzVlZS00NTI5LWJjYjUtMzkwNTUzMWMxZTllXkEyXkFqcGdeQXVyNDIzMzcwNjc@._V1_UY268_CR7,0,182,268_AL_.jpg",
                "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia.",
                2011,
                "David Benioff, D.B. Weiss",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Lucifer",
                "https://m.media-amazon.com/images/M/MV5BNzY1YjIxOGMtOTAyZC00YTcyLWFhMzQtZTJkYTljYzU0MGRlXkEyXkFqcGdeQXVyMTAwMzM3NDI3._V1_UY268_CR0,0,182,268_AL_.jpg",
                "Lucifer Morningstar has decided he's had enough of being the dutiful servant in Hell and decides to spend some time on Earth to better understand humanity. He settles in Los Angeles - the City of Angels.",
                2016,
                "Tom Kapinos",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Walking Dead",
                "https://m.media-amazon.com/images/M/MV5BYTUwOTM3ZGUtMDZiNy00M2I3LWI1ZWEtYzhhNGMyZjI3MjBmXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "Sheriff Deputy Rick Grimes wakes up from a coma to learn the world is in ruins and must lead a group of survivors to stay alive.",
                2010,
                "Frank Darabont, Angela Kang",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Vikings",
                "https://m.media-amazon.com/images/M/MV5BNjIzZjljZmQtOGNiYi00YmY2LWE1MGYtN2VlMmEyZDBlMzRmXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "Vikings transports us to the brutal and mysterious world of Ragnar Lothbrok, a Viking warrior and farmer who yearns to explore - and raid - the distant shores across the ocean.",
                2013,
                "Michael Hirst",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Stranger Things",
                "https://m.media-amazon.com/images/M/MV5BMjEzMDAxOTUyMV5BMl5BanBnXkFtZTgwNzAxMzYzOTE@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces in order to get him back.",
                2016,
                "Matt Duffer, Ross Duffer",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Daredevil",
                "https://m.media-amazon.com/images/M/MV5BODcwOTg2MDE3NF5BMl5BanBnXkFtZTgwNTUyNTY1NjM@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "A blind lawyer by day, vigilante by night. Matt Murdock fights the crime of New York as Daredevil.",
                2015,
                "Drew Goddard",
                2
            )
        )

        movies.add(
            Movie(
                ++id,
                "Inception",
                "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
                2010,
                "Christopher Nolan",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Wolf of Wall Street",
                "https://m.media-amazon.com/images/M/MV5BMjIxMjgxNTk0MF5BMl5BanBnXkFtZTgwNjIyOTg2MDE@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "Based on the true story of Jordan Belfort, from his rise to a wealthy stock-broker living the high life to his fall involving crime, corruption and the federal government.",
                2013,
                "Martin Scorsese",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "The Dark Knight Rises",
                "https://m.media-amazon.com/images/M/MV5BMTk4ODQzNDY3Ml5BMl5BanBnXkFtZTcwODA0NTM4Nw@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "Eight years after the Joker's reign of anarchy, Batman, with the help of the enigmatic Catwoman, is forced from his exile to save Gotham City from the brutal guerrilla terrorist Bane.",
                2012,
                "Christopher Nolan",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "Logan",
                "https://m.media-amazon.com/images/M/MV5BYzc5MTU4N2EtYTkyMi00NjdhLTg3NWEtMTY4OTEyMzJhZTAzXkEyXkFqcGdeQXVyNjc1NTYyMjg@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "In a future where mutants are nearly extinct, an elderly and weary Logan leads a quiet life. But when Laura, a mutant child pursued by scientists, comes to him for help, he must get her to safety.",
                2017,
                "James Mangold",
                1
            )
        )

        movies.add(
            Movie(
                ++id,
                "Life Is Beautiful",
                "https://m.media-amazon.com/images/M/MV5BYmJmM2Q4NmMtYThmNC00ZjRlLWEyZmItZTIwOTBlZDQ3NTQ1XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_UX182_CR0,0,182,268_AL_.jpg",
                "When an open-minded Jewish librarian and his son become victims of the Holocaust, he uses a perfect mixture of will, humor, and imagination to protect his son from the dangers around their camp.",
                1997,
                "Roberto Benigni",
                1
            )
        )

        return movies
    }

    fun generateDummyStars(): List<Star> {
        val stars = ArrayList<Star>()
        var id = 0

        stars.add(
            Star(
                ++id,
                "Christian Bale",
                "https://m.media-amazon.com/images/M/MV5BMTkxMzk4MjQ4MF5BMl5BanBnXkFtZTcwMzExODQxOA@@._V1_SY1000_CR0,0,665,1000_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Heath Ledger",
                "https://m.media-amazon.com/images/M/MV5BMTI2NTY0NzA4MF5BMl5BanBnXkFtZTYwMjE1MDE0._V1_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Bryan Cranston",
                "https://m.media-amazon.com/images/M/MV5BMTA2NjEyMTY4MTVeQTJeQWpwZ15BbWU3MDQ5NDAzNDc@._V1_SY1000_CR0,0,668,1000_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Aaron Paul",
                "https://m.media-amazon.com/images/M/MV5BMTY1OTY5NjI5NV5BMl5BanBnXkFtZTcwODA4MjM0OA@@._V1_SY1000_CR0,0,665,1000_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Robert Downey Jr.",
                "https://m.media-amazon.com/images/M/MV5BNzg1MTUyNDYxOF5BMl5BanBnXkFtZTgwNTQ4MTE2MjE@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Chris Evans",
                "https://m.media-amazon.com/images/M/MV5BMTU2NTg1OTQzMF5BMl5BanBnXkFtZTcwNjIyMjkyMg@@._V1_UY317_CR6,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Mark Ruffalo",
                "https://m.media-amazon.com/images/M/MV5BNDQyNzMzZTMtYjlkNS00YzFhLWFhMTctY2M4YmQ1NmRhODBkXkEyXkFqcGdeQXVyNjcyNzgyOTE@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Joaquin Phoenix",
                "https://m.media-amazon.com/images/M/MV5BZGMyY2Q4NTEtMWVkZS00NzcwLTkzNmQtYzBlMWZhZGNhMDhkXkEyXkFqcGdeQXVyNjk1MjYyNTA@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Robert De Niro",
                "https://m.media-amazon.com/images/M/MV5BMjAwNDU3MzcyOV5BMl5BanBnXkFtZTcwMjc0MTIxMw@@._V1_UY317_CR13,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Zazie Beetz",
                "https://m.media-amazon.com/images/M/MV5BNjEwNzEwYjQtYWUwNy00YWZlLWE5ZmQtMDBiMjc5ZjdiMjc1XkEyXkFqcGdeQXVyNjEyNzc2MTI@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Matthew McConaughey",
                "https://m.media-amazon.com/images/M/MV5BMTg0MDc3ODUwOV5BMl5BanBnXkFtZTcwMTk2NjY4Nw@@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Mackenzie Foy",
                "https://m.media-amazon.com/images/M/MV5BYTIyMzExODgtNzllNy00OWQwLTlhM2QtMWU1ZTI2MjgwMTQxXkEyXkFqcGdeQXVyMjQwMDg0Ng@@._V1_UY317_CR6,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Anne Hathaway",
                "https://m.media-amazon.com/images/M/MV5BMTRhNzQ3NGMtZmQ1Mi00ZTViLTk3OTgtOTk0YzE2YTgwMmFjXkEyXkFqcGdeQXVyNzg5MzIyOA@@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Ellen Page",
                "https://m.media-amazon.com/images/M/MV5BMTU3MzM3MDYzMV5BMl5BanBnXkFtZTcwNzk1Mzc3NA@@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Tom Hopper",
                "https://m.media-amazon.com/images/M/MV5BN2Y1OGZjNWUtYTdmMy00OGQxLTg5MmYtOTRjMjMxZWI1NTJhXkEyXkFqcGdeQXVyMjQwMDg0Ng@@._V1_UY317_CR131,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Aidan Gallagher",
                "https://m.media-amazon.com/images/M/MV5BNWJkOWQzMzMtMGQ2Ni00ZmZiLTk3OTYtZDVmNDc4MTU5Njc5XkEyXkFqcGdeQXVyNDM1MDk1NDI@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Henry Cavill",
                "https://m.media-amazon.com/images/M/MV5BODI0MTYzNTIxNl5BMl5BanBnXkFtZTcwNjg2Nzc0NA@@._V1_UY317_CR26,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Amy Adams",
                "https://m.media-amazon.com/images/M/MV5BMTg2NTk2MTgxMV5BMl5BanBnXkFtZTgwNjcxMjAzMTI@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Michael Shannon",
                "https://m.media-amazon.com/images/M/MV5BMjE0NzM5MTc5OF5BMl5BanBnXkFtZTgwMjc3ODYxODE@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Freya Allan",
                "https://m.media-amazon.com/images/M/MV5BZGQ4NDRjNjEtYThjMS00ZGQ4LThlM2QtOTgwYzJhZTg3NWNhXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_UY317_CR5,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Anya Chalotra",
                "https://m.media-amazon.com/images/M/MV5BZmViNmEwMjgtYTIxNi00YWJjLWI5OWEtNTczYTM1ZmRjM2UzXkEyXkFqcGdeQXVyMTA1MDUzMjgx._V1_UY317_CR12,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Karl Urban",
                "https://m.media-amazon.com/images/M/MV5BMTU2Njg3MDgyN15BMl5BanBnXkFtZTcwNjgyNTA4Mg@@._V1_UY317_CR5,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Jack Quaid",
                "https://m.media-amazon.com/images/M/MV5BY2Y2MmIzOGEtNTgyYi00OWUyLTljNzEtYmFlOWU2MzFkZTg1XkEyXkFqcGdeQXVyMjYyNDg5NzY@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Antony Starr",
                "https://m.media-amazon.com/images/M/MV5BMTQxMDg1Nzc0OV5BMl5BanBnXkFtZTcwODc4NTkyNw@@._V1_UY317_CR6,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Peter Dinklage",
                "https://m.media-amazon.com/images/M/MV5BMTM1MTI5Mzc0MF5BMl5BanBnXkFtZTYwNzgzOTQz._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Lena Headey",
                "https://m.media-amazon.com/images/M/MV5BMzIwMjIwNjg0M15BMl5BanBnXkFtZTgwOTI3MDEzMDE@._V1_UY317_CR14,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Emilia Clarke",
                "https://m.media-amazon.com/images/M/MV5BNjg3OTg4MDczMl5BMl5BanBnXkFtZTgwODc0NzUwNjE@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Kit Harington",
                "https://m.media-amazon.com/images/M/MV5BMTA2NTI0NjYxMTBeQTJeQWpwZ15BbWU3MDIxMjgyNzY@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Tom Ellis",
                "https://m.media-amazon.com/images/M/MV5BYmY2OGMzM2YtMDVlNi00NzdhLTkzNDMtZjA0M2I2YzNiNDIyXkEyXkFqcGdeQXVyNjc1OTk0NzA@._V1_UY317_CR17,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Lauren German",
                "https://m.media-amazon.com/images/M/MV5BMTUzNjY0NTA0Ml5BMl5BanBnXkFtZTgwMTUxMTMyNjE@._V1_UY317_CR6,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Kevin Alejandro",
                "https://m.media-amazon.com/images/M/MV5BMTA0NDkyNzI0MTBeQTJeQWpwZ15BbWU4MDI4ODUxODUx._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Norman Reedus",
                "https://m.media-amazon.com/images/M/MV5BMTQ5ODE4NTgzMl5BMl5BanBnXkFtZTcwODI0MjAwMw@@._V1_UY317_CR5,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Melissa McBride",
                "https://m.media-amazon.com/images/M/MV5BMTcwNzAwMzc3OF5BMl5BanBnXkFtZTcwNzIzNjU3Nw@@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Danai Gurira",
                "https://m.media-amazon.com/images/M/MV5BNjYyNjg1OTU1M15BMl5BanBnXkFtZTgwNzYyNTkzMDI@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Katheryn Winnick",
                "https://m.media-amazon.com/images/M/MV5BZWE3NGE3NWUtNDA4NC00ODYyLThmMTgtNjQ4Y2ZkYzdmMmQ5XkEyXkFqcGdeQXVyMTE1MzA3MTI@._V1_UY317_CR131,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Alexander Ludwig",
                "https://m.media-amazon.com/images/M/MV5BZjNhMzJjNDItMzQyNy00MTcxLWJkNmYtNDljNDBmMWJhNjdhXkEyXkFqcGdeQXVyMTQyOTM4MzU@._V1_UY317_CR7,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Winona Ryder",
                "https://m.media-amazon.com/images/M/MV5BMTQ3NzM3MTc2NF5BMl5BanBnXkFtZTcwODMxNjA0NA@@._V1_UY317_CR9,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "David Harbour",
                "https://m.media-amazon.com/images/M/MV5BZTc5ODUzMDAtZGFhZS00NmExLTlhYWYtZDY0NGI2MGMwYTIzXkEyXkFqcGdeQXVyODY0MzQyODc@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Finn Wolfhard",
                "https://m.media-amazon.com/images/M/MV5BYjM2NmFiNGYtODQ1OC00ZTE5LTg4ZWYtYjFmODk4YmUyZDMzXkEyXkFqcGdeQXVyNjQ3NDAwOTA@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Charlie Cox",
                "https://m.media-amazon.com/images/M/MV5BMjA0Mzg5MTU3MV5BMl5BanBnXkFtZTgwOTUxMTQ5NzE@._V1_UY317_CR144,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Deborah Ann Woll",
                "https://m.media-amazon.com/images/M/MV5BMjE2NjA4NzYyMV5BMl5BanBnXkFtZTcwODEwNjQyMw@@._V1_UY317_CR26,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Elden Henson",
                "https://m.media-amazon.com/images/M/MV5BMjAxNzczMjE2Ml5BMl5BanBnXkFtZTcwNzg3MzUzMQ@@._V1_UY317_CR13,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Leonardo DiCaprio",
                "https://m.media-amazon.com/images/M/MV5BMjI0MTg3MzI0M15BMl5BanBnXkFtZTcwMzQyODU2Mw@@._V1_UY317_CR10,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Joseph Gordon-Levitt",
                "https://m.media-amazon.com/images/M/MV5BMTY3NTk0NDI3Ml5BMl5BanBnXkFtZTgwNDA3NjY0MjE@._V1_UY317_CR3,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Jonah Hill",
                "https://m.media-amazon.com/images/M/MV5BMTUyNDU0NzAwNl5BMl5BanBnXkFtZTcwMzQxMzIzNw@@._V1_UY317_CR28,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Margot Robbie",
                "https://m.media-amazon.com/images/M/MV5BMTgxNDcwMzU2Nl5BMl5BanBnXkFtZTcwNDc4NzkzOQ@@._V1_UY317_CR12,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Gary Oldman",
                "https://m.media-amazon.com/images/M/MV5BMTc3NTM4MzQ5MV5BMl5BanBnXkFtZTcwOTE4MDczNw@@._V1_UY317_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Tom Hardy",
                "https://m.media-amazon.com/images/M/MV5BMTQ3ODEyNjA4Nl5BMl5BanBnXkFtZTgwMTE4ODMyMjE@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Hugh Jackman",
                "https://m.media-amazon.com/images/M/MV5BNDExMzIzNjk3Nl5BMl5BanBnXkFtZTcwOTE4NDU5OA@@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Patrick Stewart",
                "https://m.media-amazon.com/images/M/MV5BMTc0MzU5ODQ5OF5BMl5BanBnXkFtZTYwODIwODk1._V1_UY317_CR4,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Dafne Keen",
                "https://m.media-amazon.com/images/M/MV5BNjQyMzk2MDA5N15BMl5BanBnXkFtZTgwNDAyMzUxNDM@._V1_UX214_CR0,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Roberto Benigni",
                "https://m.media-amazon.com/images/M/MV5BMTUwMzI1Nzg5NF5BMl5BanBnXkFtZTYwODU5NjYz._V1_UY317_CR13,0,214,317_AL_.jpg"
            )
        )

        stars.add(
            Star(
                ++id,
                "Nicoletta Braschi",
                "https://m.media-amazon.com/images/M/MV5BMTcyMjUxNzMzOF5BMl5BanBnXkFtZTYwMzM1NDM3._V1_UY317_CR104,0,214,317_AL_.jpg"
            )
        )
        stars.add(
            Star(
                ++id,
                "Giorgio Cantarini",
                "https://m.media-amazon.com/images/M/MV5BYjdhNTFiYTYtOGE4Ni00NTVjLTlhMGYtYThhNzAxZjUxMmM5XkEyXkFqcGdeQXVyNDM4Nzc5NzY@._V1_UY317_CR20,0,214,317_AL_.jpg"
            )
        )

        return stars
    }

    fun generateDummyCasts(): List<Cast> {
        val casts = ArrayList<Cast>()
        var id = 0

        casts.add(
            Cast(
                ++id, 1, 1, "Bruce Wayne"
            )
        )

        casts.add(
            Cast(
                ++id, 1, 2, "Joker"
            )
        )

        casts.add(
            Cast(
                ++id, 2, 3, "Walter Whine"
            )
        )

        casts.add(
            Cast(
                ++id, 2, 4, "Jesse Pinkman"
            )
        )

        casts.add(
            Cast(
                ++id, 3, 5, "Tony Stark/Iron Man"
            )
        )

        casts.add(
            Cast(
                ++id, 3, 6, "Steve Rogers/Captain America"
            )
        )

        casts.add(
            Cast(
                ++id, 3, 7, "Bruce Banner/Hulk"
            )
        )

        casts.add(
            Cast(
                ++id, 4, 8, "Arthur Fleck"
            )
        )

        casts.add(
            Cast(
                ++id, 4, 9, "Murray Franklin"
            )
        )

        casts.add(
            Cast(
                ++id, 4, 10, "Sophie Dumond"
            )
        )

        casts.add(
            Cast(
                ++id, 5, 11, "Cooper"
            )
        )

        casts.add(
            Cast(
                ++id, 5, 12, "Murph"
            )
        )

        casts.add(
            Cast(
                ++id, 5, 13, "Brand"
            )
        )

        casts.add(
            Cast(
                ++id, 6, 14, "Vanya Hargreeves"
            )
        )

        casts.add(
            Cast(
                ++id, 6, 15, "Luther Hargreeves"
            )
        )

        casts.add(
            Cast(
                ++id, 6, 16, "Number Five"
            )
        )

        casts.add(
            Cast(
                ++id, 7, 17, "Clark Kent/Kal-El"
            )
        )

        casts.add(
            Cast(
                ++id, 7, 18, "Lois Lane"
            )
        )

        casts.add(
            Cast(
                ++id, 7, 19, "General Zod"
            )
        )

        casts.add(
            Cast(
                ++id, 8, 17, "Geralt of Rivia"
            )
        )

        casts.add(
            Cast(
                ++id, 8, 20, "Ciri"
            )
        )

        casts.add(
            Cast(
                ++id, 8, 21, "Yennefer"
            )
        )

        casts.add(
            Cast(
                ++id, 9, 22, "Billy Butcher"
            )
        )

        casts.add(
            Cast(
                ++id, 9, 23, "Hughie Campbell"
            )
        )

        casts.add(
            Cast(
                ++id, 9, 24, "Homelander"
            )
        )

        casts.add(
            Cast(
                ++id, 10, 25, "Tyrion Lannister"
            )
        )

        casts.add(
            Cast(
                ++id, 10, 26, "Cersei Lannister"
            )
        )

        casts.add(
            Cast(
                ++id, 10, 27, "Daenerys Targaryen"
            )
        )

        casts.add(
            Cast(
                ++id, 10, 28, "Jon Snow"
            )
        )

        casts.add(
            Cast(
                ++id, 11, 29, "Lucifer Morningstar"
            )
        )

        casts.add(
            Cast(
                ++id, 11, 30, "Chloe Decker"
            )
        )

        casts.add(
            Cast(
                ++id, 11, 31, "Dan Espinoza"
            )
        )

        casts.add(
            Cast(
                ++id, 12, 32, "Daryl Dixon"
            )
        )

        casts.add(
            Cast(
                ++id, 12, 33, "Carol Peletier"
            )
        )

        casts.add(
            Cast(
                ++id, 12, 34, "Michonne"
            )
        )

        casts.add(
            Cast(
                ++id, 13, 35, "Lagertha"
            )
        )

        casts.add(
            Cast(
                ++id, 13, 36, "Bjorn Lothbrok"
            )
        )

        casts.add(
            Cast(
                ++id, 14, 37, "Joyce Byers"
            )
        )

        casts.add(
            Cast(
                ++id, 14, 38, "Jim Hopper"
            )
        )

        casts.add(
            Cast(
                ++id, 14, 39, "Mike Wheeler"
            )
        )

        casts.add(
            Cast(
                ++id, 15, 40, "Matt Murdock"
            )
        )

        casts.add(
            Cast(
                ++id, 15, 41, "Karen Page"
            )
        )

        casts.add(
            Cast(
                ++id, 15, 42, "Foggy Nelson"
            )
        )

        casts.add(
            Cast(
                ++id, 16, 43, "Cobb"
            )
        )

        casts.add(
            Cast(
                ++id, 16, 14, "Ariadne"
            )
        )

        casts.add(
            Cast(
                ++id, 16, 44, "Arthur"
            )
        )

        casts.add(
            Cast(
                ++id, 17, 43, "Jordan Belfort"
            )
        )

        casts.add(
            Cast(
                ++id, 17, 45, "Donnie Azoff"
            )
        )

        casts.add(
            Cast(
                ++id, 17, 46, "Naomi Lapaglia"
            )
        )

        casts.add(
            Cast(
                ++id, 18, 1, "Bruce Wayne"
            )
        )

        casts.add(
            Cast(
                ++id, 18, 47, "Commissioner Gordon"
            )
        )

        casts.add(
            Cast(
                ++id, 18, 48, "Bane"
            )
        )

        casts.add(
            Cast(
                ++id, 18, 44, "Blake"
            )
        )

        casts.add(
            Cast(
                ++id, 19, 49, "Logan / X-24"
            )
        )

        casts.add(
            Cast(
                ++id, 19, 50, "Charles"
            )
        )

        casts.add(
            Cast(
                ++id, 19, 51, "Laura"
            )
        )

        casts.add(
            Cast(
                ++id, 20, 52, "Guido"
            )
        )

        casts.add(
            Cast(
                ++id, 20, 53, "Dora"
            )
        )

        casts.add(
            Cast(
                ++id, 20, 54, "Giosue"
            )
        )
        return casts
    }
}