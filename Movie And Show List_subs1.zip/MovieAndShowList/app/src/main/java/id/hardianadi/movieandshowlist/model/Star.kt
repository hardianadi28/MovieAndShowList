package id.hardianadi.movieandshowlist.model

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
data class Star(
    val id: Int,
    val name: String,
    val photo: String
)