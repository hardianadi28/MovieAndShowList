package id.hardianadi.movieandshowlist.viewmodel

import androidx.lifecycle.ViewModel
import id.hardianadi.movieandshowlist.model.Cast
import id.hardianadi.movieandshowlist.model.Movie
import id.hardianadi.movieandshowlist.util.DataDummy

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class MovieDetailViewModel : ViewModel() {
    private var idMovie: Int = 0
    private var movie: Movie? = null

    fun setIdMovie(idMovie: Int, type: Int) {
        this.idMovie = idMovie
        setMovie(type)
    }


    private fun setMovie(type: Int) {
        val movieList = DataDummy.generateDummyMovies().filter { it.type == type }
        movieList.forEach {
            if (it.id == idMovie) {
                it.casts = populateCasts(it)
                movie = it
            }
        }
    }

    private fun populateCasts(movie: Movie): List<Cast> {
        val casts = DataDummy.generateDummyCasts().filter { cast -> cast.idMovie == movie.id }
        casts.forEach {
            it.star = DataDummy.generateDummyStars().find { star -> star.id == it.idStar }
        }

        return casts
    }

    fun getMovie() = movie
}