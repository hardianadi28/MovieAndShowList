package id.hardianadi.movieandshowlist.ui.movie

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import id.hardianadi.movieandshowlist.R
import id.hardianadi.movieandshowlist.model.Movie
import id.hardianadi.movieandshowlist.ui.detail.MovieDetailActivity
import id.hardianadi.movieandshowlist.viewmodel.MovieViewModel
import kotlinx.android.synthetic.main.fragment_movie.*

class MovieFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_movie, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            val viewModel = ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            )[MovieViewModel::class.java]
            val movies = viewModel.getMovieList()
            val movieAdapter = MovieAdapter()
            movieAdapter.setMovies(movies)
            movieAdapter.setOnClickItemListener(object : MovieAdapter.OnClickItemListener {
                override fun onClick(movie: Movie) {
                    val intent = Intent(requireContext(), MovieDetailActivity::class.java)
                    intent.putExtra(MovieDetailActivity.EXTRA_ID_MOVIE, movie.id)
                    intent.putExtra(MovieDetailActivity.EXTRA_TYPE_MOVIE, movie.type)
                    startActivity(intent)
                }

            })
            prepareRecyclerView(movieAdapter)
        }
    }

    private fun prepareRecyclerView(movieAdapter: MovieAdapter) {
        with(rvMovie) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = movieAdapter
        }
    }

}