package id.hardianadi.movieandshowlist.ui.show

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import id.hardianadi.movieandshowlist.R
import id.hardianadi.movieandshowlist.model.Movie
import id.hardianadi.movieandshowlist.ui.detail.MovieDetailActivity
import id.hardianadi.movieandshowlist.ui.movie.MovieAdapter
import id.hardianadi.movieandshowlist.viewmodel.ShowViewModel
import kotlinx.android.synthetic.main.fragment_show.*

class ShowFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_show, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            val viewModel = ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            )[ShowViewModel::class.java]
            val movies = viewModel.getShows()
            val movieAdapter = MovieAdapter()
            movieAdapter.setMovies(movies)
            movieAdapter.setOnClickItemListener(object : MovieAdapter.OnClickItemListener {
                override fun onClick(movie: Movie) {
                    val intent = Intent(requireContext(), MovieDetailActivity::class.java)
                    intent.putExtra(MovieDetailActivity.EXTRA_ID_MOVIE, movie.id)
                    intent.putExtra(MovieDetailActivity.EXTRA_TYPE_MOVIE, movie.type)
                    startActivity(intent)
                }

            })
            prepareRecyclerView(movieAdapter)
        }
    }

    private fun prepareRecyclerView(movieAdapter: MovieAdapter) {
        with(rvShow) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = movieAdapter
        }
    }
}