package id.hardianadi.movieandshowlist.viewmodel

import org.junit.Before
import org.junit.Test

import org.junit.Assert.*

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel
    private val movieTotal = 10

    @Before
    fun setUp() {
        viewModel = MovieViewModel()
    }

    @Test
    fun getMovieList() {
        val movies = viewModel.getMovieList()
        assertNotNull(movies)
        assertEquals(movies.size, movieTotal)
    }
}