package id.hardianadi.movieandshowlist.viewmodel

import org.junit.Before
import org.junit.Test

import org.junit.Assert.*

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class ShowViewModelTest {

    private lateinit var viewModel: ShowViewModel
    private val showTotal = 10

    @Before
    fun setUp() {
        viewModel = ShowViewModel()
    }

    @Test
    fun getShows() {
        val shows = viewModel.getShows()
        assertNotNull(shows)
        assertEquals(shows.size, showTotal)
    }
}