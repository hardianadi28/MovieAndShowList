package id.hardianadi.movieandshowlist.viewmodel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @since 09/09/2020
 */
class MovieDetailViewModelTest {

    private lateinit var viewModel: MovieDetailViewModel

    private val expectedIdMovie = 1
    private val expectedMovieTitle = "The Dark Knight"
    private val expectedCastTotal = 2

    private val expectedIdShow = 2
    private val expectedShowTitle = "Breaking Bad"

    @Before
    fun setUp() {
        viewModel = MovieDetailViewModel()
        viewModel.setIdMovie(expectedIdMovie, 1)
    }


    @Test
    fun getMovie() {
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movie?.title, expectedMovieTitle)
    }

    @Test
    fun getShow() {
        viewModel.setIdMovie(expectedIdShow, 2)
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movie?.title, expectedShowTitle)
    }

    @Test
    fun populateCasts() {
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movie?.casts?.size, expectedCastTotal)
    }

}