package id.hardianadi.movieandshowlist.data

/**
 * @author hardiansyah (hardiansyah.adi@gmail.com)
 * @date 17/09/2020
 */
data class CastEntity(
    val id: Int? = null,
    val name: String? = null,
    val character: String? = null,
    val gender: Int? = null,
    val creditId: String? = null,
    val profilePath: String? = null,
    val order: Int? = null
)